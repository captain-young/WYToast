//
//  WYToast.h
//  WYToast
//
//  Created by 杨新威 on 2018/3/1.
//  Copyright © 2018年 杨新威. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface WYToast : UIView

+ (void)showWithToast:(NSString *)toast;

@end
